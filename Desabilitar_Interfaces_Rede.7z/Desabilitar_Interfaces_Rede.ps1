netsh interface set interface "Ethernet" disable
netsh interface set interface "Wi-fi" disable